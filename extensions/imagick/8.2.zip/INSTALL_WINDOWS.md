# Windows installation

## Copy extension

Copy the file `php_imagick.dll` into your PHP installation's `ext` directory.

## Copy Library Dlls

Copy all other DLL from the archive into the PHP installation directory (in the same directory as `php.exe`).

## Activate PHP extensions

Into the configuration file `php.ini` activate the `imagick` extensions like:

```ini
extension_dir=ext
extension=imagick
```
